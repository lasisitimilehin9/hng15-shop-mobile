/** Production web API + Supabase (same backend as hng15-shop). */
export const API_BASE =
  process.env.EXPO_PUBLIC_API_BASE ?? "https://hng15-shop-ltj2.vercel.app";

export const SUPABASE_URL =
  process.env.EXPO_PUBLIC_SUPABASE_URL ?? "https://yauoebacbgaxfuvibmvu.supabase.co";

/** Set EXPO_PUBLIC_SUPABASE_ANON_KEY in .env — never commit secrets. */
export const SUPABASE_ANON_KEY =
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? "";
