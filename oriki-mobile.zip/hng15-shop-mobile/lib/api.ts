import { API_BASE } from "./config";
import { supabase } from "./supabase";

async function authHeaders(): Promise<Record<string, string>> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  const h: Record<string, string> = { "Content-Type": "application/json" };
  if (token) h.Authorization = `Bearer ${token}`;
  return h;
}

export type Product = {
  id: string;
  slug: string;
  name: string;
  description: string;
  price_kobo: number;
  image_url: string | null;
  stock: number;
  active: boolean;
};

export type CartLine = {
  productId: string;
  quantity: number;
  name?: string;
  price_kobo?: number;
  image_url?: string | null;
  slug?: string;
};

export async function fetchProducts(): Promise<Product[]> {
  // Public products via Supabase client (RLS select active)
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("active", true)
    .order("name");
  if (error) throw error;
  return (data as Product[]) ?? [];
}

export async function getCart(): Promise<CartLine[]> {
  const headers = await authHeaders();
  const res = await fetch(`${API_BASE}/api/cart`, { headers });
  if (res.status === 401) return [];
  if (!res.ok) throw new Error("Failed to load cart");
  const json = await res.json();
  return (json.items ?? []).map(
    (i: {
      productId: string;
      quantity: number;
      name?: string;
      price_kobo?: number;
      image_url?: string | null;
      slug?: string;
    }) => ({
      productId: i.productId,
      quantity: i.quantity,
      name: i.name,
      price_kobo: i.price_kobo,
      image_url: i.image_url,
      slug: i.slug,
    })
  );
}

export async function putCart(
  items: { productId: string; quantity: number }[]
): Promise<void> {
  const headers = await authHeaders();
  const res = await fetch(`${API_BASE}/api/cart`, {
    method: "PUT",
    headers,
    body: JSON.stringify({ items }),
  });
  if (!res.ok) throw new Error("Failed to save cart");
}

export async function checkout(body: {
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  shipping_address: string;
  shipping_city: string;
  shipping_state: string;
  notes?: string;
  items: { productId: string; quantity: number }[];
}): Promise<{ order_ref: string }> {
  const headers = await authHeaders();
  const res = await fetch(`${API_BASE}/api/checkout`, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || "Checkout failed");
  return json;
}

export async function fetchOrders() {
  const headers = await authHeaders();
  const res = await fetch(`${API_BASE}/api/orders`, { headers });
  if (!res.ok) throw new Error("Failed to load orders");
  return res.json();
}

export function formatNaira(kobo: number): string {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    minimumFractionDigits: 0,
  }).format(kobo / 100);
}
