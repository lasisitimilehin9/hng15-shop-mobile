import { create } from "zustand";
import type { CartLine } from "./api";
import { getCart, putCart } from "./api";

type State = {
  items: CartLine[];
  loading: boolean;
  load: () => Promise<void>;
  setQty: (productId: string, quantity: number) => Promise<void>;
  add: (line: CartLine) => Promise<void>;
  remove: (productId: string) => Promise<void>;
  clear: () => Promise<void>;
};

export const useCartStore = create<State>((set, get) => ({
  items: [],
  loading: false,
  load: async () => {
    set({ loading: true });
    try {
      const items = await getCart();
      set({ items });
    } finally {
      set({ loading: false });
    }
  },
  setQty: async (productId, quantity) => {
    let items = get().items;
    if (quantity <= 0) {
      items = items.filter((i) => i.productId !== productId);
    } else {
      items = items.map((i) =>
        i.productId === productId ? { ...i, quantity } : i
      );
    }
    set({ items });
    await putCart(items.map((i) => ({ productId: i.productId, quantity: i.quantity })));
  },
  add: async (line) => {
    const items = [...get().items];
    const idx = items.findIndex((i) => i.productId === line.productId);
    if (idx >= 0) {
      items[idx] = {
        ...items[idx],
        quantity: Math.min(99, items[idx].quantity + line.quantity),
      };
    } else {
      items.push(line);
    }
    set({ items });
    await putCart(items.map((i) => ({ productId: i.productId, quantity: i.quantity })));
  },
  remove: async (productId) => {
    const items = get().items.filter((i) => i.productId !== productId);
    set({ items });
    await putCart(items.map((i) => ({ productId: i.productId, quantity: i.quantity })));
  },
  clear: async () => {
    set({ items: [] });
    await putCart([]);
  },
}));
