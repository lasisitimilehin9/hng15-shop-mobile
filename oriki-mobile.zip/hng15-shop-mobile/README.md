# Oriki Naturals Mobile

Expo app using the **same** Supabase + Next.js API as the web shop.

## Setup

```bash
cp .env.example .env
# set EXPO_PUBLIC_SUPABASE_ANON_KEY from Supabase → Project Settings → API → anon public
npm install
npx expo start
```

Scan the QR code with **Expo Go** (Android) to run without an APK.

## APK (install on phone)

```bash
npm i -g eas-cli
eas login
eas build -p android --profile preview
```

When the build finishes, open the link on your phone and install the APK.

## Google on mobile

Add this redirect in Supabase URL config and Google Cloud if using Google:

- `oriki://`
- Expo auth redirect from `makeRedirectUri({ scheme: "oriki" })`

Email/password works against the same project without extra setup.
