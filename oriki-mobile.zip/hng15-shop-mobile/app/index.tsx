import { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  Pressable,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { Link } from "expo-router";
import { fetchProducts, formatNaira, type Product } from "@/lib/api";
import { useCartStore } from "@/lib/cart-store";

export default function ShopScreen() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const add = useCartStore((s) => s.add);
  const total = useCartStore((s) =>
    s.items.reduce((n, i) => n + i.quantity, 0)
  );

  useEffect(() => {
    fetchProducts()
      .then((list) =>
        setProducts(
          list.filter((p) => p.active && p.image_url && p.image_url.trim())
        )
      )
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
    useCartStore
      .getState()
      .load()
      .catch(() => {});
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color="#2d5a3d" />
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <View style={styles.bar}>
        <Link href="/login" asChild>
          <Pressable>
            <Text style={styles.link}>Account</Text>
          </Pressable>
        </Link>
        <Link href="/orders" asChild>
          <Pressable>
            <Text style={styles.link}>Orders</Text>
          </Pressable>
        </Link>
        <Link href="/cart" asChild>
          <Pressable>
            <Text style={styles.cart}>Cart ({total})</Text>
          </Pressable>
        </Link>
      </View>
      {error ? <Text style={styles.err}>{error}</Text> : null}
      <FlatList
        data={products}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ padding: 16, gap: 12 }}
        ListEmptyComponent={
          <Text style={{ color: "#57534e" }}>No products available.</Text>
        }
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.image_url! }} style={styles.img} />
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.price}>{formatNaira(item.price_kobo)}</Text>
            <Pressable
              style={styles.btn}
              onPress={() =>
                add({
                  productId: item.id,
                  quantity: 1,
                  name: item.name,
                  price_kobo: item.price_kobo,
                  image_url: item.image_url,
                  slug: item.slug,
                }).catch((e) => setError(String(e.message || e)))
              }
            >
              <Text style={styles.btnText}>Add to cart</Text>
            </Pressable>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  bar: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#e7e5e4",
  },
  link: { color: "#2d5a3d", fontWeight: "600" },
  cart: { color: "#2d5a3d", fontWeight: "700" },
  err: { color: "#b91c1c", padding: 12 },
  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: "#e7e5e4",
  },
  img: { width: "100%", height: 160, borderRadius: 8, backgroundColor: "#e7e5e4" },
  name: { marginTop: 8, fontSize: 16, fontWeight: "600", color: "#1c1917" },
  price: { marginTop: 4, color: "#2d5a3d", fontWeight: "600" },
  btn: {
    marginTop: 10,
    backgroundColor: "#2d5a3d",
    paddingVertical: 10,
    borderRadius: 999,
    alignItems: "center",
  },
  btnText: { color: "#fff", fontWeight: "600" },
});
