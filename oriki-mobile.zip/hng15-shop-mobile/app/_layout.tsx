import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";

export default function RootLayout() {
  return (
    <>
      <StatusBar style="dark" />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: "#faf8f5" },
          headerTintColor: "#2d5a3d",
          contentStyle: { backgroundColor: "#faf8f5" },
        }}
      >
        <Stack.Screen name="index" options={{ title: "Oriki Naturals" }} />
        <Stack.Screen name="cart" options={{ title: "Cart" }} />
        <Stack.Screen name="login" options={{ title: "Account" }} />
        <Stack.Screen name="orders" options={{ title: "Orders" }} />
        <Stack.Screen name="checkout" options={{ title: "Checkout" }} />
      </Stack>
    </>
  );
}
