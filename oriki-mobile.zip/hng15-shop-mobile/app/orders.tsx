import { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { fetchOrders, formatNaira } from "@/lib/api";

type Order = {
  id: string;
  order_ref: string;
  total_kobo: number;
  status: string;
};

export default function OrdersScreen() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrders()
      .then((d) => setOrders(d.orders ?? d ?? []))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color="#2d5a3d" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.err}>{error}</Text>
        <Text>Sign in on the Account screen to view orders.</Text>
      </View>
    );
  }

  return (
    <FlatList
      data={orders}
      keyExtractor={(o) => o.id}
      contentContainerStyle={{ padding: 16 }}
      ListEmptyComponent={<Text>No orders yet.</Text>}
      renderItem={({ item }) => (
        <View style={styles.card}>
          <Text style={styles.ref}>{item.order_ref}</Text>
          <Text>{item.status}</Text>
          <Text style={styles.total}>{formatNaira(item.total_kobo)}</Text>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 16,
  },
  err: { color: "#b91c1c", textAlign: "center" },
  card: {
    padding: 12,
    marginBottom: 10,
    backgroundColor: "#fff",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#e7e5e4",
  },
  ref: { fontWeight: "700" },
  total: { color: "#2d5a3d", marginTop: 4, fontWeight: "600" },
});
