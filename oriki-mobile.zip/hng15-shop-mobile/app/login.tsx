import { useState } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  TextInput,
  ActivityIndicator,
} from "react-native";
import * as WebBrowser from "expo-web-browser";
import { makeRedirectUri } from "expo-auth-session";
import { supabase } from "@/lib/supabase";
import { useRouter } from "expo-router";
import { useCartStore } from "@/lib/cart-store";

WebBrowser.maybeCompleteAuthSession();

export default function LoginScreen() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function afterAuth() {
    await useCartStore.getState().load().catch(() => {});
    router.replace("/");
  }

  async function signInEmail() {
    setLoading(true);
    setMsg(null);
    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    setLoading(false);
    if (error) {
      setMsg(error.message);
      return;
    }
    await afterAuth();
  }

  async function signUpEmail() {
    setLoading(true);
    setMsg(null);
    const { error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
    });
    setLoading(false);
    if (error) {
      setMsg(error.message);
      return;
    }
    setMsg("Account created. If email confirmation is on, check your inbox.");
  }

  async function signInGoogle() {
    setLoading(true);
    setMsg(null);
    try {
      const redirectTo = makeRedirectUri({ scheme: "oriki" });
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo,
          skipBrowserRedirect: true,
        },
      });
      if (error) throw error;
      if (!data.url) throw new Error("No OAuth URL");
      const result = await WebBrowser.openAuthSessionAsync(
        data.url,
        redirectTo
      );
      if (result.type === "success" && result.url) {
        const url = new URL(result.url);
        const params = new URLSearchParams(
          url.hash.replace(/^#/, "") || url.search.replace(/^\?/, "")
        );
        const access_token = params.get("access_token");
        const refresh_token = params.get("refresh_token");
        if (access_token && refresh_token) {
          await supabase.auth.setSession({ access_token, refresh_token });
          await afterAuth();
        } else {
          setMsg("Signed in window closed. Try email login if Google fails.");
        }
      }
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Google sign-in failed");
    } finally {
      setLoading(false);
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    useCartStore.getState().clear().catch(() => {});
    setMsg("Signed out");
  }

  return (
    <View style={styles.root}>
      <Text style={styles.title}>Account</Text>
      <Text style={styles.hint}>
        Same Supabase backend as the web shop. Cart and orders sync when you are
        signed in.
      </Text>

      <Pressable
        style={styles.btnGoogle}
        onPress={signInGoogle}
        disabled={loading}
      >
        <Text style={styles.btnGoogleText}>Continue with Google</Text>
      </Pressable>

      <Text style={styles.or}>or email</Text>

      <TextInput
        style={styles.input}
        autoCapitalize="none"
        keyboardType="email-address"
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        secureTextEntry
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
      />
      {msg ? <Text style={styles.msg}>{msg}</Text> : null}
      {loading ? <ActivityIndicator color="#2d5a3d" /> : null}

      <Pressable style={styles.btn} onPress={signInEmail} disabled={loading}>
        <Text style={styles.btnText}>Sign in</Text>
      </Pressable>
      <Pressable
        style={styles.btnOutline}
        onPress={signUpEmail}
        disabled={loading}
      >
        <Text style={styles.btnOutlineText}>Create account</Text>
      </Pressable>
      <Pressable onPress={signOut}>
        <Text style={styles.signOut}>Sign out</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, padding: 20, gap: 12 },
  title: { fontSize: 22, fontWeight: "700", color: "#1c1917" },
  hint: { color: "#57534e", marginBottom: 4 },
  or: { textAlign: "center", color: "#78716c", marginVertical: 4 },
  input: {
    borderWidth: 1,
    borderColor: "#d6d3d1",
    borderRadius: 10,
    padding: 12,
    backgroundColor: "#fff",
  },
  msg: { color: "#b91c1c" },
  btn: {
    backgroundColor: "#2d5a3d",
    padding: 14,
    borderRadius: 999,
    alignItems: "center",
  },
  btnText: { color: "#fff", fontWeight: "600" },
  btnGoogle: {
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#d6d3d1",
    padding: 14,
    borderRadius: 999,
    alignItems: "center",
  },
  btnGoogleText: { color: "#1c1917", fontWeight: "600" },
  btnOutline: {
    borderWidth: 1,
    borderColor: "#2d5a3d",
    padding: 14,
    borderRadius: 999,
    alignItems: "center",
  },
  btnOutlineText: { color: "#2d5a3d", fontWeight: "600" },
  signOut: { textAlign: "center", color: "#78716c", marginTop: 8 },
});
