import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import { useCartStore } from "@/lib/cart-store";
import { checkout, formatNaira } from "@/lib/api";

export default function CheckoutScreen() {
  const items = useCartStore((s) => s.items);
  const clear = useCartStore((s) => s.clear);
  const router = useRouter();
  const [form, setForm] = useState({
    customer_name: "",
    customer_email: "",
    customer_phone: "",
    shipping_address: "",
    shipping_city: "",
    shipping_state: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const total = items.reduce(
    (s, i) => s + (i.price_kobo || 0) * i.quantity,
    0
  );

  async function submit() {
    if (!items.length) {
      setError("Cart is empty");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await checkout({
        ...form,
        items: items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
        })),
      });
      await clear();
      router.replace({
        pathname: "/orders",
        params: { ref: res.order_ref },
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Checkout failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.root}>
      <Text style={styles.total}>Total: {formatNaira(total)}</Text>
      {(
        [
          ["customer_name", "Full name"],
          ["customer_email", "Email"],
          ["customer_phone", "Phone"],
          ["shipping_address", "Address"],
          ["shipping_city", "City"],
          ["shipping_state", "State"],
        ] as const
      ).map(([key, label]) => (
        <TextInput
          key={key}
          style={styles.input}
          placeholder={label}
          autoCapitalize={key === "customer_email" ? "none" : "words"}
          keyboardType={
            key === "customer_email"
              ? "email-address"
              : key === "customer_phone"
                ? "phone-pad"
                : "default"
          }
          value={form[key]}
          onChangeText={(t) => setForm((f) => ({ ...f, [key]: t }))}
        />
      ))}
      {error ? <Text style={styles.err}>{error}</Text> : null}
      <Pressable
        style={[styles.btn, (loading || !items.length) && styles.btnDisabled]}
        onPress={submit}
        disabled={loading || !items.length}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.btnText}>Place order</Text>
        )}
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { padding: 16, gap: 10 },
  total: { fontSize: 18, fontWeight: "700", marginBottom: 8, color: "#2d5a3d" },
  input: {
    borderWidth: 1,
    borderColor: "#d6d3d1",
    borderRadius: 10,
    padding: 12,
    backgroundColor: "#fff",
  },
  err: { color: "#b91c1c" },
  btn: {
    backgroundColor: "#2d5a3d",
    padding: 14,
    borderRadius: 999,
    alignItems: "center",
    marginTop: 8,
  },
  btnDisabled: { opacity: 0.5 },
  btnText: { color: "#fff", fontWeight: "600" },
});
