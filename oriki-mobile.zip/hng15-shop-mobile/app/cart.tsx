import { View, Text, FlatList, Pressable, StyleSheet } from "react-native";
import { Link } from "expo-router";
import { useCartStore } from "@/lib/cart-store";
import { formatNaira } from "@/lib/api";

export default function CartScreen() {
  const items = useCartStore((s) => s.items);
  const setQty = useCartStore((s) => s.setQty);
  const remove = useCartStore((s) => s.remove);
  const totalKobo = items.reduce(
    (s, i) => s + (i.price_kobo || 0) * i.quantity,
    0
  );

  if (items.length === 0) {
    return (
      <View style={styles.center}>
        <Text>Your cart is empty</Text>
        <Link href="/" asChild>
          <Pressable>
            <Text style={styles.link}>Browse products</Text>
          </Pressable>
        </Link>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={items}
        keyExtractor={(i) => i.productId}
        contentContainerStyle={{ padding: 16 }}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{item.name}</Text>
              <Text>{formatNaira((item.price_kobo || 0) * item.quantity)}</Text>
              <View style={styles.qty}>
                <Pressable onPress={() => setQty(item.productId, item.quantity - 1)}>
                  <Text style={styles.qtyBtn}>−</Text>
                </Pressable>
                <Text>{item.quantity}</Text>
                <Pressable onPress={() => setQty(item.productId, item.quantity + 1)}>
                  <Text style={styles.qtyBtn}>+</Text>
                </Pressable>
                <Pressable onPress={() => remove(item.productId)}>
                  <Text style={styles.remove}>Remove</Text>
                </Pressable>
              </View>
            </View>
          </View>
        )}
      />
      <View style={styles.footer}>
        <Text style={styles.total}>Total: {formatNaira(totalKobo)}</Text>
        <Link href="/checkout" asChild>
          <Pressable style={styles.btn}>
            <Text style={styles.btnText}>Checkout</Text>
          </Pressable>
        </Link>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  link: { color: "#2d5a3d", fontWeight: "600" },
  row: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#e7e5e4",
  },
  name: { fontWeight: "600", marginBottom: 4 },
  qty: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 8 },
  qtyBtn: { fontSize: 20, color: "#2d5a3d", paddingHorizontal: 8 },
  remove: { color: "#b91c1c", marginLeft: 8 },
  footer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: "#e7e5e4",
    gap: 12,
  },
  total: { fontSize: 18, fontWeight: "700" },
  btn: {
    backgroundColor: "#2d5a3d",
    padding: 14,
    borderRadius: 999,
    alignItems: "center",
  },
  btnText: { color: "#fff", fontWeight: "600" },
});
